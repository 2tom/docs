yum-epel Cookbook CHANGELOG
======================
This file is used to list changes made in each version of the yum-centos cookbook.

v0.4.0 (2014-07-27)
-------------------
- [#9] Allowing list of repositories to reference configurable.


v0.3.6 (2014-04-09)
-------------------
- [COOK-4509] add RHEL7 support to yum-epel cookbook


v0.3.4 (2014-02-19)
-------------------
COOK-4353 - Fixing typo in readme


v0.3.2 (2014-02-13)
-------------------
Updating README to explain the 'managed' parameter


v0.3.0 (2014-02-12)
-------------------
[COOK-4292] - Do not manage secondary repos by default


v0.2.0
------
Adding Amazon Linux support


v0.1.6
------
Fixing up attribute values for EL6


v0.1.4
------
Adding CHANGELOG.md


v0.1.0
------
initial release
